<?php
/**
* GOLDENFORMS version 1.0
* Copyright (c) 2012 Max @ GoldenForms.com, All rights reserved.
* Author: Max (GoldenForms.com)
* @license		GNU/GPL
* Visit http://www.GoldenForms.com for regular updates and information.
**/
namespace GCore\Admin\Modules\Tasks;
/* @copyright:ChronoEngine.com @license:GPLv2 */defined('_JEXEC') or die('Restricted access');
defined("GCORE_SITE") or die;
class Tasks extends \GCore\Helpers\Module{
	var $helpers = array('\GCore\Helpers\Tasks', '\GCore\Helpers\Assets', '\GCore\Helpers\Html');
	
	public static function display($module){
		
	}
}