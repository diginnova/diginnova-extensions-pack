<?php
/**
* COMPONENT FILE HEADER
**/
namespace GCore\Extensions\Chronoconnectivity\Controllers;
/* @copyright:ChronoEngine.com @license:GPLv2 */defined('_JEXEC') or die('Restricted access');
defined("GCORE_SITE") or die;
class Lists extends \GCore\Admin\Extensions\Chronoconnectivity\Controllers\Lists {
	var $area = 'front';
}
?>